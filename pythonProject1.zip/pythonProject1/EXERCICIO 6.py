N1= int(input("Number 1"))
N2= int(input("Number 2"))

if N1>N2:
     print( N2, N1)
else:
    print(N1, N2)


