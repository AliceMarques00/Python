time1=str(input("Digite o nome do primeiro time:"))
golsTime1=int(input('Digite o número de gols'))

time2=str(input("Digite o nome do segundo time:"))
golsTime2=int(input("Digite o número de gols"))

if golsTime1> golsTime2:
    print(f"{time1}é o vencedor")
if golsTime2> golsTime1:
    print(f"{time2} é o vencedor")
else :
    print("Empate")

