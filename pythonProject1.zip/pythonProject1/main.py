N1=float(input("number 1?"))
N2=float(input("number 2?"))

soma= N1+N2
Subtração= N1-N2
divisão= N1/N2
Multiplicação= N1*N2

print(f"O resultado da soma é {soma}")
print(f"O resultado da subtração é {Subtração}")
print(f"O resultado da divisão é {divisão}")
print(f"O resultado da multiplicação é {Multiplicação}")

n = int(input('Digite um número: '))
if n == 1:
    base = int(input('Digite a base do triangulo: '))
altura = int(input('Digite a altura do triangulo: '))
area = (base * altura) / 2
print(area)
elif n == 2:
ladoA = int(input('Digite a altura do quadrado: '))
ladoB = int(input('Digite a base do quadrado: '))
area = ladoA * ladoB
print(area)
else:
print('O número não corresponde!!')
'''  menu = int(input('Digite 1 para triangulo \n'
                     'Digite 2 para quadrado \n'
                     'Digite 3 para sair:'))
'''