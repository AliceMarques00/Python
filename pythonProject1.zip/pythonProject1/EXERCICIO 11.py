ValorE= 4.9
ValorG= 5.8
tipo= input("Informe o tipo de combustivel abastecido, G para gasolina ou E para etanol")
qtdLitros= float(input("Informe quantos litros voce abasteceu"))

if tipo== "g" or tipo== "G":
    total=qtdLitros*ValorG
    print("voce gastou", total)
elif tipo== "e" or tipo== "E":
    total= qtdLitros*ValorE
    print("voce gastou", total)
else:
    print("Invalido")
