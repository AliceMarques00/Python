#1)Faça um algoritmo que receba 2 notas e calcule a média aritimetica
'''n1= float(input('Digite um numero: '))
n2= float(input('Digite o segundo número: '))

media= (n1+n2)/2
print(media)'''
#2) Crie um código que leia um número diferente de zero e diga se este número é positivo ou negativon = float(input('Digite um número: '))

'''n= int(input('Digite um número: '))
if n<0:
  print('Negativo')
else n>0 :
    print('Positivo')'''

#3) Crie um código que leia a idade de uma pessoa e diga em que ano a pessoa nasceu

'''idade= int(input('Digite a sua idade: '))
mesAniversario= int(input('Digite o mes de nascimento: ')                    
ano= 2024-idade
if mesN>4:
    print(ano-1)
else:
    (ano)'''

#4)Crie um algoritmo que receba 3 numeros e informe qual o maior entre eles

'''n1= float(input('digite um número: '))
n2= float(input('digite o segundo número: '))
n3= float(input('digite o terceiro número'))
if n1>n2 and n1>n3:
 print(f'{n1}é maior')
elif n2>n1 and n2>n3:
    print(f'{n2}é maior')
elif n3> n2 and n3> n1:
    print(f'{n3}é maior')'''
#5) Crie um algoritmo que leia um número e diga se é par ou ímpar
'''
n= float(input('Digite um número: '))

if n %2 == 0:
    print('par')
else:
    print('impar')'''
#6) Receba ddo usuario um número de 1 a 12 e mostre o nome do mes correspondente. Caso o mes não existir mostre essa informação:

'''n=int(input('digite um numero'))
if n <1 or n>12:
    print('Numero invalido')
elif n==1:
    print('Janeiro')
elif n==2:
    print('Fevereiro')
elif n==3:
    print('Março')
elif n==4:
    print('Abril')
elif n==5:
    print('Maio')
elif n==6:
    print('Junho')
elif n==7:
    print('Julho')
elif n==8:
    print('Agosto')
elif n==9:
    print('Setembro')
elif n==10:
    print('Outubro')
elif n==11:
    print('Novembro')
elif n==12:
    print('Dezembro')'''
#7) Faça um codigo que receba o valor da base e da altura de um triangulo e calcule a sua area. use a formula A=(base x Altura)/2

'''base= float(input('Digite o valor da base do triangulo: '))
altura= float(input('Digite o valor da altura do triangulo'))

area= (base*altura)/2
print(f'A area é= {area}')'''

#8) Faça um codigo que receba 4 numeros e realize a soma deles e a media entre eles. E mostre os resultados
#8.1
'''n1= float(input('Digite o primeiro número: '))
n2= float(input('Digite o segundo número: '))
n3= float(input('Digite o terceiro número: '))
n4= float(input('Digite o quarto numero: '))
media=(n1+n2+n3+n4)/4
print(f'A soma é {n1+n2+n3+n4}')
print(f'A média é {media}')
'''
#8.2
'''soma=0
for x in range(4):
    n= float(input('Digite um número'))
    soma= soma + n
media= soma/4
print(f'A soma é: {soma} e a média é: {media}')'''

#Faça um codigo que receba um numero inteiro e mostre o seu antecessor

'''n= int(input('Digite um número inteiro'))
print(f'O antecessor é: {n-1}')
print(f'O numero é {n}')
print(f'O sucessor é: {n+1}')'''

#Faça um algoritmo que leia a idade de uma pessoa em anos, meses e dias e escreva a
# idade dessa pessoa expressa apenas em dias. Considerar ano com 365 dias e mes om 30 dias.
'''Anos= int(input('Digite sua idade em anos: '))
meses= int(input('Digite seus meses: '))
dias= int(input('Digite seus dias: '))
Dias2= Anos*365+meses* 30+ dias
print(Dias2)'''

#Faça um código que receba o valor da base e da altura do triangulo e calcule sua área. Usando a formula A=(base*altura)/2
menu=0
while menu!=3:
    menu = int(input('Digite 1 para triangulo \n'
                     'Digite 2 para quadrado \n'
                     'Digite 3 para sair:'))
    if menu == 1:
        base = int(input('Digite a base do triangulo: '))
        altura = int(input('Digite a altura do triangulo: '))
        areaT = (base * altura) / 2
        print(areaT)
    elif menu == 2:
        ladoA = int(input('Digite a altura do quadrado: '))
        ladoB = int(input('Digite a base do quadrado: '))
        area = ladoA * ladoB
        print(area)
    elif menu!= 3:
         print('O número não corresponde!!')
print('FIM')
