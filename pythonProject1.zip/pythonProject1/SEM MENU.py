n=0
while n!=3:
    n = int(input('Digite um número: '))
    if n == 1:
        base = int(input('Digite a base do triangulo: '))
        altura = int(input('Digite a altura do triangulo: '))
        areaT = (base * altura) / 2
        print(areaT)
    elif n == 2:
        ladoA = int(input('Digite a altura do quadrado: '))
        ladoB = int(input('Digite a base do quadrado: '))
        area = ladoA * ladoB
        print(area)
    elif n!= 3:
         print('O número não corresponde!!')
print('FIM')
