def ():
    print("Pense em um número entre 1 e 100.")
    input("Pressione Enter quando estiver pronto...")
