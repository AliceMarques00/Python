N1= float(input("Digite um número"))
if N1 % 2 == 0:

     print(f"o número {N1} é par")
else:
    print(f"o número {N1} é ímpar")
