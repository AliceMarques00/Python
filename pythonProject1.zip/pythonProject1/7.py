idade= int(input('Digite a sua idade: '))
mes= int('Digite o mes do seu aniversario')
mesAtual= 4
anoAtual=2024
anoNascimento= anoAtual-idade
if mes>mesAtual:
    print(anoNascimento)
else:
    (an)
