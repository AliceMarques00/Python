nomeCompleto= input("Digite o seu nome")
nota1= float(input("Digite a primeira nota"))
nota2= float(input("Digite a segunda nota"))

media=(nota1+nota2)/2
print("nome do aluno", nomeCompleto)
print("média do aluno", media)



